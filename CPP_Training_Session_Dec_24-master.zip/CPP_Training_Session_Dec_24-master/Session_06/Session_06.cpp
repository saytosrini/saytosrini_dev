
#include <iostream>

using namespace std;

void main()
{
///Size to declare
	///0 is the default position

#pragma region Method-1 Array Declaration

	/*string _9pmBatch[2]; ///Array Declaration

	_9pmBatch[0] = "Hariharan"; ///Value Assigning
	_9pmBatch[1] = "Srinivasan";

	cout << _9pmBatch[0] << endl; ///Printing
	cout << _9pmBatch[1] << endl;*/

#pragma endregion

#pragma region Method-2 Array Declaration

	/*string _9pmBatch[] = { "Hariharan","Srinivasan" };

	cout << _9pmBatch[0] << endl; ///Printing
	cout << _9pmBatch[1] << endl;*/

#pragma endregion

#pragma region Get Input for array (from user)

	/*string names[5];

	int index = 0;

	while (index < sizeof(names) / sizeof(string))
	{
		cout << "Enter Name: ";
		cin >> names[index];

		index++;

		system("cls");
	}
*/

#pragma endregion

#pragma region Manupulate Array using Loops

	string names[] = { "hari","Srini","Harsha","Fees","Worth" };

	//cout << names[0] << endl;
	//cout << names[1] << endl;
	//cout << names[2] << endl;
	//cout << names[3] << endl;
	//cout << names[4] << endl;

	/*for (int i = 0; i < sizeof(names) / sizeof(string); i++)
	{
		cout << names[i] << endl;
	}*/

	///I need to take everything (no validation)

	///foreach loop
	for (string name : names)
	{
		if (name == "Harsha" || name == "Srini")
		{
			cout << name << endl;
		}
	}

#pragma endregion

}