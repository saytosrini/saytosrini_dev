#include <iostream>

using namespace std;


void main()
{

#pragma region Loop Introduction

	//	int i = 1;
	//
	//start:
	//
	//	cout << i << endl;
	//
	//	if (i == 10)
	//	{
	//		goto end;
	//	}
	//
	//	i++;
	//
	//	goto start;
	//
	//end:
	//
	//	cout << "Application Ended";

#pragma endregion

#pragma region While

	/////Init
	//int i = 10;

	/////Cond
	//while (i >= 1)
	//{
	//	cout << i << endl;

	//	//itt
	//	i--;
	//}


#pragma endregion

#pragma region do While

	/*int i = 1;

	do
	{
		cout << i << endl;

		i++;

	} while (i <= 10);*/


#pragma endregion

#pragma region For Loop

	/*for (int i = 1; i <= 10; i++)
	{
		cout << i << endl;
	}*/

#pragma endregion

#pragma region Problem with while loop

	/////1. User => 5 => Sum if N 
	/////1+2+3+4+5 => ans ?? [loop]
	///// <= N (Cond)
	///// ++ (Replacing the same number)

	////Init
	//int n = 0;

	///// Get Input from user
	//cout << "Enter Number: ";
	//cin >> n; //5

	/////Using While
	//int i = 1;

	/////Output variable
	//int addValue = 0;

	//while (i <= n)
	//{
	//	//addValue += addValue + i;
	//	addValue += i;
	//	i++;
	//}

	///// User Output
	//cout << addValue << endl;


#pragma endregion

#pragma region Problem with for loop

///1. User => 5 => Sum if N 
	///1+2+3+4+5 => ans ?? [loop]
	/// <= N (Cond)
	/// ++ (Replacing the same number)

	//Init
	int n = 0;

	/// Get Input from user
	cout << "Enter Number: ";
	cin >> n; //5

	///Output variable
	int addValue = 0;
	
	for (int i = 1; i <= n; i++)
	{
		addValue += i;
	}

	/// User Output
	cout << addValue << endl;

#pragma endregion

}