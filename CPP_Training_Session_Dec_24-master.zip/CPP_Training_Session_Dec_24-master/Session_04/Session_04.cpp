
#include <iostream>
using namespace std;


void main()
{
	///if (cond)
	///{
	/// 
	/// 
	///}

	///if(cond)
	///{
	/// 
	///}
	///else
	///{
	/// 
	///}
	/// 
	/// Relations Operators
	/// > => greater than
	/// < => lesser than
	/// >=
	/// <=
	/// ==
	/// 
	/// Conditional Operators
	/// && => AND
	/// || => OR
	/// ! => NOT (Reverse)

#pragma region if & else statement
//
//	int age = 0;
//
//start:
//
//	cout << "Enter Age: ";
//	cin >> age;
//
//	if (age > 18)
//	{
//		cout << "Eligible for voting" << endl;
//		goto end;
//	}
//	else
//	{
//		cout << "Not Eligible for voting" << endl;
//		system("pause");
//		system("cls");
//
//		goto start;
//	}
//
//end:
//	if (!(age < 25 || age>18))
//	{
//		cout << "Young Guy";
//	}


#pragma endregion

#pragma region if else if

//
//	int time = 0;
//
//start:
//
//	///Ask Input from the user
//	cout << "Enter Time: ";
//	cin >> time;
//
//	if (time >= 0 && time <= 24)
//	{
//		cout << "Enter Value with 24" << endl;
//
//		system("pause");
//		system("cls");
//
//		goto start;
//	}
//
//	if (time < 10)
//	{
//		cout << "Good Morning";
//	}
//	else if (time < 20)
//	{
//		cout << "Good Day";
//	}
//	else
//	{
//		cout << "Good Evening";
//	}

#pragma endregion

#pragma region Switch Statement

	int dayNumber = 3;

	switch (dayNumber)
	{
	case 1:
		cout << "Sunday" << endl;
		break;

	case 2:
		cout << "Monday" << endl;
		break;

	case 3:
		cout << "Tuesday" << endl;
		break;

	case 4:
		cout << "Wednesday" << endl;
		break;

	case 5:
		cout << "Thursday" << endl;
		break;

	case 6:
		cout << "Friday" << endl;
		break;

	case 7:
		cout << "Saturday" << endl;
		break;

	default:

		cout << "Enter Number from 1-7" << endl;

		break;
	}

	int age = 18;


	/*switch (age >18)
	{

	case true:

		cout << "Eligible for voting" << endl;

		break;

	default:

		cout << "Not Eligible" << endl;
		break;
	}*/


#pragma endregion

}
