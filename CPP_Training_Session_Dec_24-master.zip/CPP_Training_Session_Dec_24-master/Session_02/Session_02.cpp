
#include <iostream>

using namespace std;


void main()
{
	///Function
	///Input
	/// Process
	/// Output

	//cout << "Hello Guys!!" << endl;

	///DataTypes (Data + Type)
	/// int => 4 byte
	/// double
	/// char
	/// string
	/// bool
	///Variables
	/// Operators
	/// +
	/// -
	/// *
	/// /
	/// %

	///camelCase
	///gitHub

	int number_1 = 10.1; //(address)
	double number_2 = 20.2;
	char charater = 'A';
	string squence = "Hello Guys!!";
	bool yesOrNo = true;

	//cout << addressof(number_1) << endl;

	//cout << number_1 << endl;
	//cout << number_2 << endl;
	//cout << charater << endl;
	//cout << squence << endl;
	//cout << yesOrNo;

	int num1 = 10;
	int num2 = 20;

	double num_3 = 5.2;
	double num_4 = 10.535;

	double add = num1 + num2;
	int mul = num1 * num2;
	int div = 20 / 10;
	int mod = 20 % 10;
	int sub = num1 - num2;

	int sub_2 = num_3 - num_4; //-5

	cout << add << endl;

}

