#include <iostream>

using namespace std;

void main()
{

#pragma region 2D Array


	///2D Array Declaration
	int points[4][3];

	///Feed Value to Array

	///Point - 1
	points[0][0] = 0;
	points[0][1] = 0;
	points[0][2] = 0;

	///Point - 2
	points[1][0] = 200;
	points[1][1] = 0;
	points[1][2] = 0;

	///Point - 3
	points[2][0] = 200;
	points[2][1] = 100;
	points[2][2] = 0;


	///Point - 4
	points[3][0] = 0;
	points[3][1] = 100;
	points[3][2] = 0;

	///Nested Loops
	/*for (int row = 0; row < 4; row++)
	{
		for (int col = 0; col < 3; col++)
		{
			int val = points[row][col];
			cout << val;
			cout << " ";
		}

		cout << "\n";
	}*/

	///P3-P1 (To Form a Vector) (double => int)
	double vec_X = points[2][0] - points[0][0];
	double vec_Y = points[2][1] - points[0][1];
	double vec_Z = points[2][2] - points[0][2];

	///Calculate the Distance
	///01.Square the Vector Coords
	double vec_X_pow = pow(vec_X, 2);
	double vec_Y_pow = pow(vec_Y, 2);
	double vec_Z_pow = pow(vec_Z, 2);

	///02. Sqrt (BODMAS) (PEMDAS)
	double dist = sqrt((vec_X_pow + vec_Y_pow + vec_Z_pow));

	///03. Display the Value
	cout << dist << endl;


#pragma endregion





}
