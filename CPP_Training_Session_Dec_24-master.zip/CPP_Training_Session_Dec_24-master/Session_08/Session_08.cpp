#include <iostream>

using namespace std;

class Point3d
{
public:

	int X = 0;
	int Y = 0;
	int Z = 0;

	void Display()
	{
		cout << "(" << X << "," << Y << "," << Z << ")" << endl;
	}

};


void main()
{


#pragma region Without using OOPS

	int x1, y1, z1 = 0;
	int x2, y2, z2 = 0;


	cout << "Enter X1: ";
	cin >> x1;

	cout << "Enter Y1: ";
	cin >> y1;

	cout << "Enter Z1: ";
	cin >> z1;

	cout << "Enter X2: ";
	cin >> x2;

	cout << "Enter Y2: ";
	cin >> y2;

	cout << "Enter Z2: ";
	cin >> z2;

	cout << "(" << x1 << "," << y1 << "," << z1 << ")" << endl;
	cout << "(" << x2 << "," << y2 << "," << z2 << ")" << endl;

#pragma endregion


#pragma region Using OOPS

	Point3d p1;
	p1.X = 10;
	p1.Y = 20;
	p1.Z = 30;
	p1.Display();

	Point3d p2;
	p2.X = 30;
	p2.Y = 20;
	p2.Z = 10;
	p2.Display();

#pragma endregion




}

