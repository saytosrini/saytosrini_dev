/* Getting Input
   string concat
   Working with Angles
   Escape Sequence*/

#include <iostream>

using namespace std;

void main()
{

#pragma region Getting Input

	/*///Get two input from the user and add it

	///Variable Declare
	double num_1 = 0.0;
	double num_2 = 0.0;

	///Getting input from the user
	cout << "Enter First Number: ";
	cin >> num_1;

	cout << "Enter Second Number: ";
	cin >> num_2;

	double add = num_1 + num_2;

	system("cls");

	cout << add;*/

#pragma endregion

#pragma region String Concat

	int i = 10;
	int j = 20;

	int k = i + j; //30

	/*string name_1 = "Fees";
	string name_2 = "worth";*/

	///1st Way
	//string fullName = name_1 + name_2;

	///2nd Way
	//string fullName = name_1.append(name_2);

	///3rd Way
	char name_1[] = "Fees";
	char name_2[] = "Worth";

	cout << name_1;
	strcat_s(name_1, name_2);

	cout << name_1;

#pragma endregion

#pragma region Angle

	/*double deg = 30.0;
	double rad = (deg * 3.14159) / 180;
	double sinVal = sin(rad);

	cout << sinVal;*/

#pragma endregion

#pragma region Escape Sequence

	//string name = "Fees Worth \n Bangalore";
	//string name = "Fees Worth \t Bangalore";
	//string name = "Fees Worth Bangalore \n";

	//cout << name;


#pragma endregion

}


